function modelB_bound()
global beta p;
p=25;

Y=zeros(101,2);
fig=figure(1);
clf();
subplot(2,2,1);
hold on;

for beta=0.1:0.2:0.9
    b0=local_b(0);
    for k=1:101
        x=(k-1)*0.01;
        Y(k,1)=k-1;
        Y(k,2)=local_b(x)/b0;
    end
    plot(Y(:,1),Y(:,2));
    text(20,Y(21,2)-0.02,num2str(beta));
end
xlabel('distance (\mu m)');
ylabel('lower bound ([LR]/[LR]|_{X=0})');
box on;
title('(A)');

beta=0.2;

subplot(2,2,2);
hold on;
for p0=1:5
    p=p0*p0;
    b0=local_b(0);
    for k=1:101
        x=(k-1)*0.01;
        Y(k,1)=k-1;
        Y(k,2)=local_b(x)/b0;
    end
    plot(Y(:,1),Y(:,2));
    text(20,Y(21,2)-0.01,num2str(p));
end
xlabel('distance (\mu m)');
ylabel('lower bound ([LR]/[LR]|_{X=0})');
box on;
title('(B)');

exportfig(fig,'modelB_bound.eps','FontMode','fixed','FontSize','10','color','cmyk');
end

function b=local_b(x)
global beta p;
a=beta/(1-beta) * sinh(sqrt(p)*(1-x))/sinh(sqrt(p));
b=a/(1+a);
end