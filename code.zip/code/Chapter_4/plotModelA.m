function plotModelA()
A=load('modelA-1.dat');
X=0:100;
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
for k=1:20
    plot(X,A(5*k,2:102));
end
for k=70:10:100
    t=k/100;
    text(15,A(k,16),num2str(t));
end
xlabel('distance (\mu m)');
ylabel('[L]/R_{tot}');
xlim([0 100]);
ylim([0 1]);
box on;
title('(A)');
subplot(2,2,2);
hold on;
for k=1:20
    plot(X,A(5*k,103:203));
end
for k=50:25:100
    t=k/100;
    J=find(A(k,103:203)<0.7);
    r=J(1)-1;
    text(r,0.7,num2str(t));
end
xlabel('distance (\mu m)');
ylabel('[LR]/R_{tot}');
box on;
xlim([0 100]);
ylim([0 1]);
title('(B)');

exportfig(fig,'modelA.eps','FontMode','fixed','FontSize','10','color','cmyk');
end