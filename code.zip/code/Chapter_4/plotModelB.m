function plotModelB()
A=load('modelB.dat');
B=load('modelB-h.dat');
X=0:100;
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
for k=1:20
    plot(X,A(5*k,103:203));
end
xlabel('distance (\mu m)');
ylabel('[LR]/R_{tot}');
xlim([0 100]);
box on;
title('(A)');
subplot(2,2,2);
hold on;
for k=1:20
    plot(X,B(5*k,103:203));
end
xlabel('distance (\mu m)');
ylabel('[LR]/R_{tot}');
box on;
xlim([0 100]);
title('(B)');

exportfig(fig,'modelB.eps','FontMode','fixed','FontSize','10','color','cmyk');
end