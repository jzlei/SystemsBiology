function plotmodelB_m()
A=load('modelB-2.dat');
B=load('modelB.dat');
X=0:100;
fig=figure(1);
clf();
subplot(2,2,1);
plot(X,A(100,2:102)/A(100,2));
xlabel('distance (\mu m)');
ylabel('[L]/R_{tot}');
box on;
title('(A)');
subplot(2,2,2);
hold on;
plot(X,A(100,103:203)/A(100,103));
plot(X,B(10,103:203)/B(10,103),'--');
text(52,0.25,'\leftarrow');
text(55,0.25,'shadow');
xlabel('distance (\mu m)');
ylabel('[LR]/R_{tot}');
box on;
title('(B)');
exportfig(fig,'modelB_m.eps','FontMode','fixed','FontSize','10','color','cmyk');
end