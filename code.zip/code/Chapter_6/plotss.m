function plotss()
Y1=load('Y1.dat');
Y2=load('Y2.dat');
Y3=load('Y3.dat');
Y4=load('Y4.dat');
fig=figure(1);
clf();
subplot(2,3,1);
hold on;
plot(Y1(:,1),Y1(:,2),'k');
plot(Y1(:,1),Y1(:,3),'k');
plot(Y2(:,2),Y2(:,3),'b-o');
line([-1, 1.5],[0, 0],'Color','k');
line([0, 0],[-2.5,1],'Color','k');
xlim([-1 1.5]);
ylim([-2.5 1]);
text(-0.5,-1,'Stable');
text(0.5,-2,'Unstable');
text(0.578839,-1.2117,'*');
xlabel('a');
ylabel('b');
box on;

title('(A)');

subplot(2,3,2);
hold on;
plot(Y1(:,1),Y1(:,2),'k');
plot(Y1(:,1),Y1(:,3),'k');
plot(Y3(:,2),Y3(:,3),'b--');
line([-1, 1.5],[0, 0],'Color','k');
line([0, 0],[-2.5,1],'Color','k');
xlim([-1 1.5]);
ylim([-2.5 1]);
text(-0.5,-1,'Stable');
text(0.5,-2,'Unstable');
text(0.578839,-1.2117,'*');
xlabel('a');
ylabel('b');
box on;

title('(B)');

subplot(2,3,3);
hold on;
plot(Y1(:,1),Y1(:,2),'k');
plot(Y1(:,1),Y1(:,3),'k');
plot(Y4(:,2),Y4(:,3),'b-+');
line([-1, 1.5],[0, 0],'Color','k');
line([0, 0],[-2.5,1],'Color','k');
text(-0.5,-1,'Stable');
text(0.5,-2,'Unstable');
text(0.578839,-1.2117,'*');
xlabel('a');
ylabel('b');
box on;
xlim([-1 1.5]);
ylim([-2.5 1]);
title('(C)');

exportfig(fig,'ss.eps','FontMode','fixed','FontSize',10,'color','cmyk');

end