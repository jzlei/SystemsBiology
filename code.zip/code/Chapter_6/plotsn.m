function plotsn()
A1=load('sn50.dat');
A2=load('sn100.dat');
fig=figure(1);
clf();
axes('position',[0.1,0.75,0.35,0.2]);
J0=501:1001;
hold on;
plot(A1(J0,1)-50,A1(J0,2));
plot(A2(:,1)+50,A2(:,2));
text(46,2,'\rightarrow');
box on;
ylabel('Neutrophil (\times 10^8 cell/kg)');
axes('position',[0.1,0.5,0.35,0.2]);
hold on;
plot(A1(J0,1)-50,A1(J0,3));
plot(A2(:,1)+50,A2(:,3));
text(50,0.4,'\uparrow');
ylabel('HSC (\times 10^6 cell/kg)');
box on;

exportfig(fig,'sn.eps','FontMode','fixed','FontSize',10,'color','cmyk');

end