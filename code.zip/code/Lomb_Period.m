%
% The function Lomb_Period find the Period of data X, 
% return the Lomb value with given Period T.
%

function P = Lomb_Period(X, T)

t = X(:,1);
x = X(:,2);
m = size(X,1);
xbar = mean(x);
sigma2 = var(x);

omega = 2*pi/T;
s1 = sum(sin(2*omega*t(1:m)));
s2 = sum(cos(2*omega*t(1:m)));
tau = (1/(2*omega))*atan(s1/s2);

x = x -xbar;
t = t - tau;
ss1 = sum(x(1:m).*sin(omega*t(1:m)))^2;
ss2 = sum(sin(omega*t(1:m)).*sin(omega*t(1:m)));
ss3 = sum(x(1:m).*cos(omega*t(1:m)))^2;
ss4 = sum(cos(omega*t(1:m)).*cos(omega*t(1:m)));
P = (1/sigma2)*(ss1/ss2 + ss3/ss4);
                                    