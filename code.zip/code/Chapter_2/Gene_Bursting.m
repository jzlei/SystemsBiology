function Gene_Bursting()
A=load('Gene_fast.dat');
B=load('SlowLambda1.dat');
C=load('FastLambda1.dat');
fig1=figure(1);
clf();
subplot(2,2,1);
plot(B(:,1)/60,B(:,4),'k');
xlim([0 1000]);
xlabel('Time (min)');
ylabel('Number of proteins');
box on;
title('(A)');

subplot(2,2,2);
hold on;
plot(C(:,1)/60,C(:,4),'k');
plot(A(:,1)/60,A(:,4),'k--');
xlim([0 500]);
xlabel('Time (min)');
ylabel('Number of proteins');
box on;
title('(B)');
exportfig(fig1,'GeneBursting.eps','FontMode','fixed','FontSize','10','color','cmyk');
end