function CircdianTysonBif()
A=load('circadiantysonBif.dat');
B=load('circadiantysonPhase.dat');
C=load('circadiantysonsimple.dat');
fig=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,2:3),'b-');
xlabel('K_{eq}');
ylabel('k_{p1}');
text(50,13,'Circadian Oscillation');
text(25,25,'Stable steady state');
text(100,10,'*');
box on;
title('(A)');

subplot(2,2,2);
hold on;
plot(B(:,1),B(:,2:3),'b-');
plot(C(:,3),C(:,2));
text(0.3,4.0,'dM/dt=0');
text(1,2.0,'dP_T/dt=0');
xlabel('P_T');
ylabel('M');
box on;
ylim([0 5]);
title('(B)');
exportfig(fig,'CircadianTysonBif.eps','FontMode','fixed','FontSize','10','color','cmyk');

end