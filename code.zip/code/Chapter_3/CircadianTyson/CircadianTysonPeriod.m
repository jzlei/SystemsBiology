function CircadianTysonPeriod()

fig=figure(1);
clf();

subplot(2,2,1);
tau=load('kp1.dat');
n=size(tau,1);
X=zeros(n,5);
Y=size(41,2);
J=1000:2000;
B=zeros(1001,2);
for k=1:n
    A=load(strcat('output/output-',num2str(k),'.dat'));
    B(:,1)=A(J,1);
    B(:,2)=A(J,3)+2*A(J,4);
    for t=1:41
        Y(t,1)=t;
        Y(t,2)=Lomb_Period(B,t+9);
    end
    T=Y(find(Y(:,2)==max(Y(:,2))),1);
    X(k,:)=[tau(k,2),2.2595,max(B(:,2)),min(B(:,2)),T];
end
J0=1:n;
semilogy(X(J0,1),X(J0,3));
hold on;
plot(X(J0,1),X(J0,4));
J1=20:158;
plot(X(J1,1),X(J1,5),'--');
text(15,30,'Period');
line([20, 20],[X(101,4),X(101,3)],'LineStyle',':');
text(21,0.1,'Amplitude');
xlabel('k_{p1}');
ylabel('Protein Level');
title('(A)');

subplot(2,2,2);
A=load('circadiantysonfull.dat');
X=load('circadiantysonfull20.dat');
Y=load('circadiantysonfull30.dat');

hold on;
plot(A(:,1),A(:,3),'r-');
plot(X(:,1),X(:,3),'b-');
plot(Y(:,1),Y(:,3),'g-');
text(5,2,'k_{p1}=10');
text(20,5.5,'k_{p1}=20');
text(35,6,'k_{p1}=30');
xlabel('Time (hr)');
ylabel('Protein Level');
box on;
title('(B)');
exportfig(fig,'CircadianTysonSimPeriod.eps','FontMode','fixed','FontSize','10','color','cmyk');


end