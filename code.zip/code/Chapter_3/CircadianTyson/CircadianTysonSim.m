function CircadianTysonSim()
A=load('circadiantysonfull.dat');
B=load('circadiantysonsimple.dat');
fig1=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,2:3));
xlabel('Time (hr)');
ylabel('Concentrations (mRNA & Protein)');
text(16,3.5,'Protein');
text(15,1.0,'mRNA');
box on;
title('(A)');


subplot(2,2,2);
plot(B(:,1),B(:,2:3));
xlabel('Time (hr)');
ylabel('Concentrations (mRNA & Protein)');
text(13,3.0,'Protein');
text(12,0.8,'mRNA');
box on;
title('(B)');
exportfig(fig1,'CircadianTysonSim.eps','FontMode','fixed','FontSize','10','color','cmyk');

X=load('circadiantysonfull20.dat');
Y=load('circadiantysonfull30.dat');
fig2=figure(2);
clf();
subplot(2,2,1);
hold on;
plot(A(:,1),A(:,3),'r-');
plot(X(:,1),X(:,3),'b-');
plot(Y(:,1),Y(:,3),'g-');
text(5,2,'k_{p1}=10');
text(20,5.5,'k_{p1}=20');
text(35,6,'k_{p1}=30');
xlabel('Time (hr)');
ylabel('Protein Level');
box on;
exportfig(fig2,'CircadianTysonSimPeriod.eps','FontMode','fixed','FontSize','10','color','cmyk');

end