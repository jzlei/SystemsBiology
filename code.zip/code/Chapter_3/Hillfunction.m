function Hillfunction()
global C K n
C=0.8;
K=10;
n=4;

x=0:1:100;
y=zeros(101,2);
for k=1:101
    y(k,1)=local_f(x(k));
    y(k,2)=local_g(x(k));
end
fig1=figure(1);
clf();
subplot(2,2,1);
plot(x,y(:,1:2));
xlabel('X');
ylabel('f(X)');
xlim([0 40]);
ylim([0 1]);
text(20,0.48,'n=1');
text(12,0.75,'n=4');
line([0 10], [0.4 0.4],'LineStyle','--');
line([10 10],[0.4 0],'LineStyle','--');
text(11,0.2,'K=10');
exportfig(fig1,'Hillfunction.eps','FontMode','fixed','FontSize','10','color','cmyk');
end

function y=local_f(x)
global C K n
y=C*x/(K+x);
end

function y=local_g(x)
global C K n
y=C*x^n/(K^n+x^n);
end
        
