#PBS -N lac-xxx
#PBS -l nodes=1:nonvasp
cd $PBS_O_WORKDIR
./run.csh xxx
