function LacGene()
A=load('LacGene-low-to-high.dat');
B=load('LacGene-high-to-low.dat');
fig1=figure(1);
clf();
axes('position',[0.1 0.5 0.35 0.2]);
semilogy(A(:,1),A(:,2),'.');
xlabel('Extracellular TMG (\mu M)');
ylabel('LacY');
xlim([0 40]);
axes('position',[0.1 0.7 0.35 0.2]);
semilogy(B(:,1),B(:,2),'.');
box on;
set(gca,'XTickLabel',{''});
ylabel('LacY');
xlim([0 40]);
title('(A)');

X=load('low-to-high/md25.dat');
axes('position',[0.55 0.5 0.35 0.4]);
plot(X(:,1),X(:,3:2:201));
xlabel('Time');
ylabel('LacY');
ylim([0 200]);
box on;
title('(B)');

exportfig(fig1,'LacGene.eps','FontMode','fixed','FontSize','10','color','cmyk');
end