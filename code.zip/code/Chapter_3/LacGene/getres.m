function getres()
Y=zeros(4000,2);
Z=zeros(4000,2);
for k=1:40
A=load(strcat('low-to-high/md',num2str(k),'.dat'));
B=load(strcat('high-to-low/md',num2str(k),'.dat'));
m=size(A,1);
n=size(B,1);
for i=1:100
Y((k-1)*100+i,1)=A(m, 2*i);
Y((k-1)*100+i,2)=A(m, 2*i+1);
Z((k-1)*100+i,1)=B(n,2*i);
Z((k-1)*100+i,2)=B(n,2*i+1);
end
end
save 'LacGene-low-to-high.dat' Y
save 'LacGene-high-to-low.dat' Z
end
