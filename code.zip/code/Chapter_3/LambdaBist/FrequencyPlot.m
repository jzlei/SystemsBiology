function FrequencyPlot()
A1=load('fre_eta1_h_to_l.dat');
A2=load('fre_eta1_l_to_h.dat');
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
J=find(A1(:,3)>0 & A1(:,1)<3.2);
plot(A1(J,2),A1(J,3),'ro');
J=find(A2(:,3)>0 & A2(:,1)>3.5 & A2(:,1)<3.7);
plot(A2(J,2),A2(J,3),'g+');
xlabel('\eta');
ylabel('Frequency');
box on;
legend('High to Low Switching (\alpha=3.2)', 'Low to High Switching (\alpha=3.6)',4);
title('(A)');

subplot(2,2,2);
A1=load('fre_eta2_h_to_l.dat');
A2=load('fre_eta2_l_to_h.dat');
hold on;
J=find(A1(:,3)>0 & A1(:,1)>3.5 & A1(:,1)<3.7);
plot(A1(J,2),A1(J,3),'ro');
J=find(A2(:,3)>0 & A2(:,1)>4.7 & A2(:,1)<4.9);
plot(A2(J,2),A2(J,3),'g+');
xlabel('\eta');
ylabel('Frequency');
box on;
legend('High to Low Switching (\alpha=3.6)', 'Low to High Switching (\alpha=4.8)','Location', 'Best');
title('(B)');

exportfig(fig,'LambdaBistFrePar.eps','FontMode','fixed','FontSize','10','color','cmyk');

end