function Frequency()

fig=figure(1);
clf();
f=0.0;
subplot(2,2,1);
A1=load('fre_eta1_h_to_l.dat');
B1=load('fre_eta1_l_to_h.dat');
hold on;
J=find(A1(:,3)>f);
plot(A1(J,1),A1(J,2),'r.');
J=find(B1(:,3)>f);
plot(B1(J,1),B1(J,2),'g.');
ylim([0 1]);
xlabel('\alpha');
ylabel('\eta_1');
box on;
title('(A)');

subplot(2,2,2);
A1=load('fre_eta2_h_to_l.dat');
B1=load('fre_eta2_l_to_h.dat');
hold on;
J=find(A1(:,3)>f);
plot(A1(J,1),A1(J,2),'r.');
J=find(B1(:,3)>f);
plot(B1(J,1),B1(J,2),'g.');
ylim([0 1]);
xlabel('\alpha');
ylabel('\eta_2');
box on;
title('(B)');

exportfig(fig,'LambdaBistFre.eps','FontMode','fixed','FontSize','10','color','cmyk');

end

% subplot(2,2,1);
% A1=load('fre_eta1_h_to_l.dat');
% B1=load('fre_eta1_l_to_h.dat');
% 
% hold on;
% X=zeros(50,50);
% Y=zeros(50,50);
% Z=zeros(50,50);
% for i=1:50
%     for j=1:50
%         k=local_Index(A1,i,j);
%         X(i,j)=A1(k,1);
%         Y(i,j)=A1(k,2);
%         Z(i,j)=A1(k,3);
%     end
% end
% contour(X,Y,Z);
% 
% X=zeros(50,50);
% Y=zeros(50,50);
% Z=zeros(50,50);
% for i=1:50
%     for j=1:50
%         k=local_Index(B1,i,j);
%         X(i,j)=B1(k,1);
%         Y(i,j)=B1(k,2);
%         Z(i,j)=B1(k,3);
%     end
% end
% contour(X,Y,Z);
% xlabel('\alpha');
% ylabel('\eta_1');
% box on;
% title('(A)');
% 
% subplot(2,2,2);
% A1=load('fre_eta2_h_to_l.dat');
% B1=load('fre_eta2_l_to_h.dat');
% hold on;
% X=zeros(50,50);
% Y=zeros(50,50);
% Z=zeros(50,50);
% for i=1:50
%     for j=1:50
%         k=local_Index(A1,i,j);
%         X(i,j)=A1(k,1);
%         Y(i,j)=A1(k,2);
%         Z(i,j)=A1(k,3);
%     end
% end
% contour(X,Y,Z);
% 
% X=zeros(50,50);
% Y=zeros(50,50);
% Z=zeros(50,50);
% for i=1:50
%     for j=1:50
%         k=local_Index(B1,i,j);
%         X(i,j)=B1(k,1);
%         Y(i,j)=B1(k,2);
%         Z(i,j)=B1(k,3);
%     end
% end
% contour(X,Y,Z);
% xlabel('\alpha');
% ylabel('\eta_2');
% box on;
% title('(B)');
% 
% 
% end

function ind=local_Index(A,i,j)
x=3.1+i*(5.1-3.1)/50;
y=j*4.0/50;
Y=A(:,1:2)-ones(1000,1)*[x y];
Y1=abs(Y(:,1))+abs(Y(:,2));
k=find(Y1(:)==min(Y1));
ind=k;
end