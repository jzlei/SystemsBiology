function StiOsciSim()
A=load('SimOsciDet.dat');
B=load('SimOsciSto.dat');
C=load('StimuOsciDetNoOsci.dat');
D=load('StimuOsciStoNoOsci.dat');
fig1=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,2:3));
xlabel('Time');
ylabel('Concentration');
box on;
xlim([0 300]);
title('(A)');

subplot(2,2,2);
plot(B(:,1),B(:,2:3));
xlabel('Time');
ylabel('Concentration');
box on;
xlim([0 300]);
title('(B)');

subplot(2,2,3);
plot(C(:,1),C(:,3));
xlabel('Time');
ylabel('R');
box on;
xlim([0 300]);
title('(C)');

subplot(2,2,4);
plot(D(:,1),D(:,3));
xlabel('Time');
ylabel('R');
box on;
xlim([0 300]);
title('(D)');

exportfig(fig1,'StiOsciSim.eps','FontMode','fixed','FontSize','10','color','cmyk');

X=load('SimOsciDetSimple.dat');
fig2=figure(2);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,3:4));
xlabel('Time');
ylabel('Concentration');
box on;
xlim([0 200]);
title('(A)');

subplot(2,2,2);
plot(X(:,1),X(:,2:3));
xlabel('Time');
ylabel('Concentration');
box on;
xlim([0 200]);
title('(B)');
exportfig(fig2,'StiOsciSimComp.eps','FontMode','fixed','FontSize','10','color','cmyk');

end