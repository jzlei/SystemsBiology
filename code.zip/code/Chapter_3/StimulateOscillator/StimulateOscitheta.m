function StimulateOscitheta()
X=load('StimulateOsciBiftheta.dat');
Y=load('StimulateOsciBifdeltaR.dat');
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
J=find(Y(:,3)>0);
plot(Y(J,1),Y(J,2));
J=find(Y(:,3)<0);
plot(Y(J,1),Y(J,2),'--');
text(0.05,200,'Unstable');
text(0.15,100,'Stable');
xlabel('\delta_R');
ylabel('R^*');
box on;
title('(A)');

subplot(2,2,2);
loglog(X(:,1),X(:,2));
hold on;
loglog(X(:,1),X(:,3));
xlabel('\theta_A');
ylabel('\theta_R');
text(10,1000,'Periodic oscillation');
box on;
title('(B)');

exportfig(fig,'stimulateoscitheta.eps','FontMode','fixed','FontSize','10','color','cmyk');
end