function StiOsciPhase()
A=load('SimOsciSimpleNullsOsci.dat');
B=load('SimOsciDetSimpleOsci.dat');
C=load('SimOsciSimpleNullsNoOsci.dat');
D=load('SimOsciDetSimpleNoOsci.dat');
E=load('StimuOsciStoNoOsci.dat');
fig=figure(1);
clf();
subplot(2,2,1);
loglog(A(:,1),A(:,2),'r--');
hold on;
plot(A(:,1),A(:,3),'r--');
plot(B(:,2),B(:,3));
xlabel('R');
ylabel('C');
ylim([10^2 10^4]);
text(300,500,'dR/dt=0');
text(300,200,'dC/dt=0');
text(66.7491,363.47,'o');
box on;
title('(A)');

subplot(2,2,2);
loglog(C(:,1),C(:,2),'r--');
hold on;
plot(C(:,1),C(:,3),'r--');
plot(D(:,2),D(:,3));
ylim([10^2 10^4]);
xlabel('R');
ylabel('C');
text(300,400,'dR/dt=0');
text(300,200,'dC/dt=0');
text(123.268,302.7,'o');
line([123.268,0.25],[302.7,302.7],'LineStyle','--');
text(0.22,306,'\leftarrow');
text(1,250,'Noise perturb');
box on;
title('(B)');

exportfig(fig,'StiOsciPhase.eps','FontMode','fixed','FontSize','10','color','cmyk');

end