function OscillationDelay()
Y2=local_Bif(2);
Y3=local_Bif(3);
Y4=local_Bif(4);

fig=figure(1);
clf();
subplot(2,2,1);
hold on;
J=find(Y2(:,2)>0);
plot(Y2(J,1),Y2(J,2));
J=find(Y3(:,2)>0);
plot(Y3(J,1),Y3(J,2),'--');
J=find(Y4(:,2)>0);
plot(Y4(J,1),Y4(J,2),':');
xlabel('\delta');
ylabel('Time delay');
text(0.1, 2,'Stable');
text(0.15, 18,'Unstable');
box on;
ylim([0 20]);
title('(A)');

subplot(2,2,2);
hold on;
J=find(Y2(:,2)>0);
plot(Y2(J,1),Y2(J,2));
J=find(Y3(:,2)>0);
plot(Y3(J,1),Y3(J,2),'--');
J=find(Y4(:,2)>0);
plot(Y4(J,1),Y4(J,2),':');
xlabel('\delta');
ylabel('Period (2\pi/\omega)');
box on;
ylim([0 100]);
title('(B)');
exportfig(fig,'OscillationDelay.eps','FontMode','fixed','FontSize','10','color','cmyk');

end

function Y=local_Bif(p)
Y0=zeros(100,3);
for k=1:1000;
    b=k*0.001;
    f=@(x)x.^(p+1)+x-1/b;
    z=fzero(f,[0,10]);
    c=-(1+z^(-p))/p;
    if(abs(c)<1)
        omega=b*sqrt((1/c)^2 - 1);
        tau=(acos(c))/omega;
    else
        omega=0;
        tau=0;
    end
    Y0(k,1)=b;
    Y0(k,2)=tau;
    Y0(k,3)=2*pi/omega;
end
Y=Y0;
end