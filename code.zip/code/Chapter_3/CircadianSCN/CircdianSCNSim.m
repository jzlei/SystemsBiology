function CircdianSCNSim()
A=load('SCNSim.dat');
fig=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,2:3));
xlabel('Time (hr)');
ylabel('Concentrations (mRNA & Protein)');
box on;
legend('mRNA', 'Protein');
exportfig(fig,'SCNSim.eps','FontMode','fixed','FontSize','10','color','cmyk');

end