function CircdianSCNBif()
A=load('circadiandelay.dat');
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
plot(A(:,2),A(:,3));
text(0.06,5,'Stable');
text(0.4,20,'Unstable');
text(0.84,5.01,'*');
xlabel('\tau_c');
ylabel('a b');
ylim([0 30]);
xlim([0 2.0]);
box on;
title('(A)');

subplot(2,2,2);
tau=load('tau.dat');
n=size(tau,1);
X=zeros(n,5);
Y=size(41,2);
J=1000:2000;
for k=1:n
    A=load(strcat('output/output-',num2str(k),'.dat'));
    for t=1:41
        Y(t,1)=t;
        Y(t,2)=Lomb_Period(A,t+9);
    end
    T=Y(find(Y(:,2)==max(Y(:,2))),1);
    X(k,:)=[tau(k,2),2.2595,max(A(J,3)),min(A(J,3)),T];
end
J0=23:101;
semilogy(X(:,1),X(:,3));
hold on;
plot(X(:,1),X(:,4));
plot(X(J0,1),X(J0,5),'--');
plot(X(J0,1),X(J0,2),':');
%plot(X(1:23,1),X(1:23,2));
text(6,20,'Period');
line([8, 8],[X(81,4),X(81,3)],'LineStyle',':');
text(7.8,6,'Amplitude');
xlabel('\tau');
ylabel('P');
title('(B)');

exportfig(fig,'SCNBif.eps','FontMode','fixed','FontSize','10','color','cmyk');

end