function LambdaEnergy()
A=load('LambdaEnergy.dat');
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
plot(A(:,1),A(:,2));
plot(0.0643912,-0.0932253,'o','MarkerSize',5);
plot(0.276916,-0.0897452,'o','MarkerSize',5);
plot(0.573606,-0.0974415,'o','MarkerSize',5);
text(0.064,-0.095,'a');
text(0.27,-0.088,'b');
text(0.57,-0.099,'c');
line([0.24,0.30],[-0.0897453,-0.0897453]);
line([0.24,0.61],[-0.0974415,-0.0974415]);
line([0.276916,0.276916],[-0.0897453,-0.0929]);
line([0.276916,0.276916],[-0.0974415,-0.0941]);
text(0.265,-0.0935,'\Delta \phi');
xlabel('x');
ylabel('\phi(x)');
ylim([-0.1 -0.08]);
box on;

exportfig(fig,'LambdaEnergy.eps','FontMode','fixed','FontSize','10','color','cmyk');
end