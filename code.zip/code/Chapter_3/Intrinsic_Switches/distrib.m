function distrib()
N=100;
A=load('strong.dat');
Y=zeros(21,21);
[m,n]=size(A);
for k = 2:m
   for l=2:2:n-1
     a=min(round(A(k,l))+1,21);
     b=min(round(A(k,l+1))+1,21);
     Y(a,b) = Y(a,b) + 1;
   end
end
Y=Y/(N*(m-1));
save 'dis_strong.dat' Y;
