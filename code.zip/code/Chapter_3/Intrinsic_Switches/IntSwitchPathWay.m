function IntSwitchPathWay()
A=load('weak.dat');
B=load('strong.dat');
J=1:2000;
fig=figure(1);
clf();
subplot(2,2,1);
plot(A(J,1)/10^5,A(J,2));
xlabel('Time (\times 10^5)');
ylabel('[A]');
title('(A)');
box on;

subplot(2,2,2);
plot(A(J,1)/10^5,A(J,3));
xlabel('Time (\times 10^5)');
ylabel('[B]');
title('(B)');
box on;

subplot(2,2,3);
plot(B(J,1)/10^5,B(J,2));
xlabel('Time (\times 10^5)');
ylabel('[A]');
title('(C)');
box on;

subplot(2,2,4);
plot(B(J,1)/10^5,B(J,3));
xlabel('Time (\times 10^5)');
ylabel('[B]');
title('(D)');
box on;

exportfig(fig,'intrinsicswitches.eps','FontMode','fixed','FontSize','10','color','cmyk');

end