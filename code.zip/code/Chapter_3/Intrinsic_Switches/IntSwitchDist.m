function IntSwitchDist()
A=load('dis_weak.dat');
B=load('dis_strong.dat');
fig=figure(1);
clf();
subplot(2,2,1);
surf(A);
view([-1,-2,1]);
xlabel('N_A');
ylabel('N_B');
zlabel('P(N_A,N_B)');
xlim([0 20]);
ylim([0 20]);
title('(A)');

subplot(2,2,2);
surf(B);
view([-1,-2,1]);
xlabel('N_A');
ylabel('N_B');
zlabel('P(N_A,N_B)');
xlim([0 20]);
ylim([0 20]);
title('(B)');
exportfig(fig,'intrinsicswitchesdist.eps','FontMode','fixed','FontSize','10','color','cmyk');

end