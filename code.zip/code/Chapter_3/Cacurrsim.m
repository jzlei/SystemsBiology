function Cacurrsim()
A=load('cacurrsim.dat');
B=load('cacurrsim2.dat');

fig1=figure(1);
clf();
subplot(2,2,1);
hold on;
plot(A(:,1),A(:,2),'k-');
plot(B(:,1),B(:,2),'k-.','Linewidth',1.5);
xlabel('Time (ms)');
ylabel('I_{Ca} (mA)');
box on;
exportfig(fig1,'Cacurrsim.eps','FontMode','fixed','FontSize','10','color','cmyk');

