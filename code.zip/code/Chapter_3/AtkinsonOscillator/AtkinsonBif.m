function AtkinsonBif()
X=load('AtkoscibifX.dat');
Y=load('AtkoscibifY.dat');
Z=load('AtkoscibifZ.dat');
J=load('Atkoscibif.dat');
J1=load('Atkoscibifsta.dat');
fig=figure(1);
clf();
subplot(2,2,1);
surf(Y,X,Z,'EdgeColor','none');
xlabel('\alpha_2');
ylabel('a');
zlabel('x_4');
title('(A)');

subplot(2,2,2);
hold on;
plot(J(:,1),J(:,2));
plot(J(:,1),J(:,3));
plot(J1(:,1),J1(:,2),'g-');
plot(J1(:,1),J1(:,3),'g-');
text(15,1.08,'\uparrow');
text(10,1.3,'unstable');
text(60,1.6,'bistable');
text(40,2.2,'monostable');
text(60,0.8,'monostable');
xlim([0 100]);
ylim([0 3]);
xlabel('\alpha_2');
ylabel('a');
title('(B)');
box on;
exportfig(fig,'atkinsonbif.eps','FontMode','fixed','FontSize','10','color','cmyk');

end