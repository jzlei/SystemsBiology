function Atkinsondamping()
A=load('AtkosciDampingpath.dat');
B=load('AtkosciDampingpathhigh.dat');
fig=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,3));
xlabel('Time');
ylabel('x_4(t)');
box on;
title('(A)');

subplot(2,2,2);
plot(B(:,1),B(:,3));
xlabel('Time');
ylabel('x_4(t)');
box on;
title('(B)');
exportfig(fig,'atkinsondampingpath.eps','FontMode','fixed','FontSize','10','color','cmyk');


end