function Atkinsonpath()
A=load('Atkoscipath.dat');
fig=figure(1);
clf();
subplot(2,2,1);
plot(A(:,1),A(:,2));
xlabel('Time');
ylabel('x_2(t)');
box on;
title('(A)');

subplot(2,2,2);
plot(A(:,1),A(:,3));
xlabel('Time');
ylabel('x_4(t)');
box on;
title('(B)');
exportfig(fig,'atkinsonpath.eps','FontMode','fixed','FontSize','10','color','cmyk');


end