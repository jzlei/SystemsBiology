function LambdaBist()
A=load('LambdaBist.dat');
B=load('LambdaBistBif.dat');
fig=figure(1);
clf();
subplot(2,3,1);
hold on;
Y=local_f(3.0);
plot(Y(:,1),Y(:,2));
Y=local_f(4.0);
plot(Y(:,1),Y(:,2));
Y=local_f(6.0);
plot(Y(:,1),Y(:,2));
plot(Y(:,1),Y(:,1),'--');
xlabel('x');
ylabel('f(x)');
ylim([0 1.5]);
text(0.25,0.7,'\alpha=6');
text(1,0.6,'\alpha=4');
text(1.2,0.28,'\alpha=3');
box on;
title('(A)');

subplot(2,3,2);
hold on;
J=find(A(:,2)<0.0981712);
plot(A(J,1),A(J,2),'-');
J=find(A(:,2)>0.0981712 & A(:,2)<0.413874);
plot(A(J,1),A(J,2),'--');
n=size(J,1);
plot(A(J(1),1),A(J(1),2),'o');
plot(A(J(n),1),A(J(n),2),'o');
J=find(A(:,2)>0.413874);
plot(A(J,1),A(J,2),'-');
xlabel('\alpha');
ylabel('x^*');
box on;
title('(B)');

subplot(2,3,3);
hold on;
J=find(B(:,1)<0.109);
plot(B(J,1),B(J,2));
plot(B(J,1),B(J,3));
text(0.01,5,'Bistable');
text(0.04,10,'Monostable');
text(0.02,2,'Monostable');
xlabel('\gamma');
ylabel('\alpha');
box on;
ylim([0 20]);
xlim([0 0.12]);
title('(C)');
exportfig(fig,'LambdaBist.eps','FontMode','fixed','FontSize','10','color','cmyk');

end

function Y=local_f(alpha)
sigma1=1.0;
sigma2=5.0;
gamma=0.05;
Y0=zeros(100,2);
for k=1:150
    x=(k-1)*0.01;
    y=(alpha*(x^2))/(1+(1+sigma1)*(x^2)+sigma2*(x^4)) + gamma;
    Y0(k,1)=x;
    Y0(k,2)=y;
end
Y=Y0;
end