function ODE2O()

fig1=figure(1);
clf();
x=-4:0.1:4;
y=x.*x/4;
subplot(2,2,1);
plot(x,y);
axis on;
box on;
line([-4 4],[0,0]);
line([0 0],[-4,4]);
xlim([-4,4]);
ylim([-4,4]);
text(-2,-2,'Saddle');
text(2,-2,'Saddle');
text(2,0.5,'Stable Node');
text(0.8,2.5,'Stable Focus');
text(-3.7,0.5,'Unstable Node');
text(-3.0,2.5,'Unstable Focus');
text(3.75,-0.2,'p');
text(-0.4,3.75,'q');
text(3.3,2.5,'p^2=4q');
exportfig(fig1,'ode2o.eps','FontMode','fixed','FontSize','10','color','bw');
end