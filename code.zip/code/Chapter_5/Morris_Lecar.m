function Morris_Lecar()
A0=load('Iapp0.dat');
A1=load('Iapp60.dat');
A2=load('Iapp150.dat');
A3=load('Iapp300.dat');
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
plot(A0(:,1),A0(:,2));
plot(A1(:,1),A1(:,2));
plot(A2(:,1),A2(:,2));
plot(A3(:,1),A3(:,2));
text(180, -55, '0');
text(140, -30,'60');
text(100,0,'150');
text(15,60,'I_{app}=300 pA');
xlabel('t (ms)');
ylabel('V (mV)');
xlim([0 200]);
ylim([-75 75]);
box on;
exportfig(fig,'Morris_Lecar.eps','FontMode','fixed','FontSize',10,'color','cmyk');

end