function Gating()

fig1=figure(1);
clf();
X=zeros(101,5);
for k=1:101;
    V=-75+(k-1);
    X(k,1)=V;
    X(k,2)=local_f(V,-25,5);
    X(k,3)=local_f(V,-50,-2);
    X(k,4)=local_T(V,-25,5);
    X(k,5)=local_T(V,-50,-2);
end
subplot(2,2,1);
hold on;
plot(X(:,1),X(:,2:3));
text(-25,0.4,'activation');
text(-50,0.8,'inactivation');
xlabel('V (mV)');
ylabel('f_\infty(V)');
box on;
xlim([-75 25]);
title('(A)');

subplot(2,2,2);
hold on;
plot(X(:,1),X(:,4:5));
text(2,1,'activation');
text(-73,4,'inactivation');
xlabel('V (mV)');
ylabel('\tau(V)');
box on;
title('(B)');
xlim([-75 25]);

exportfig(fig1,'Gating.eps','FontMode','fixed','FontSize',10,'color','cmyk');

fig2=figure(2);
clf();
Y=zeros(100,3);
for k=1:100
    t=(k-1)/10;
    Y(k,1)=t;
    Y(k,2)=(1.0*(1-exp(-t/1.5)));
    Y(k,3)=(1.0*(1-exp(-t/1.5)))^3;
end
subplot(2,2,1);
hold on;
plot(Y(:,1),Y(:,2:3));
text(1,0.8,'P=1');
text(3,0.6,'P=3');
xlabel('Time');
ylabel('f_O(t)^P');
box on;
exportfig(fig2,'Gating2.eps','FontMode','fixed','FontSize',10,'color','cmyk');

end

function f=local_f(V,V0,S0)
f=0.5*(1+tanh((V-V0)/(2*S0)));
end

function T=local_T(V,V0,S0)
alpha=1;
beta=-1;
T=exp(V*(alpha+beta)/2)/(0.2*cosh((V-V0)/(2*S0)));
end