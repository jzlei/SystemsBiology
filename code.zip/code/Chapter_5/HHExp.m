function HHExp()
g1=load('gNA1.dat');
g2=load('gNA2.dat');
g3=load('gK1.dat');
g4=load('gK2.dat');
global a taum tauh;
global b taun;
fig=figure(1);
clf();
subplot(2,2,1);
hold on;
plot(g1(:,1),g1(:,2),'bo','LineWidth',1,'MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',5);
plot(g2(:,1),g2(:,2),'gs','LineWidth',1,'MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',5);
a=1.1279;
taum=0.15501;
tauh=0.633175;
fh=@local_f;
fplot(fh,[0,5]);
a=0.926976;
taum=0.332592;
tauh=0.897663;
fplot(fh,[0,5]);
xlabel('Time (ms)');
ylabel('g_{Na} (normalized)');
text(1.5,0.2,'V = -9 mV');
text(1.0,0.4,'V = 49 mV');
box on;
ylim([0 0.5]);
title('(A)');

subplot(2,2,2);
hold on;
plot(g3(:,1),g3(:,2),'bo','LineWidth',1,'MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',5);
plot(g4(:,1),g4(:,2),'gs','LineWidth',1,'MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',5);
a=0.958701;
b=0.210321;
taun=0.920888;
fh=@local_g;
fplot(fh,[0,10]);
a=0.876191;
b=0.287378;
taun=2.03604;
fplot(fh,[0,10]);
xlabel('Time (ms)');
ylabel('g_{K} (normalized)');
text(7,0.6,'V = -9 mV');
text(7,0.9,'V = 49 mV');
ylim([0 1]);
box on;
title('(B)');

exportfig(fig,'HHExp.eps','FontMode','fixed','FontSize',10,'color','cmyk');


end

function f=local_f(t)
global a taum tauh;
f=a*(1-exp(-t/taum))^3*exp(-t/tauh);
end

function g=local_g(t,a,b,taun)
global a b taun;
g=(a-(a-b)*exp(-t/taun))^4;
end